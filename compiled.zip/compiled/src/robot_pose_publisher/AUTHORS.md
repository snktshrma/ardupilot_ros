Original Authors
----------------

 * [Russell Toris](http://users.wpi.edu/~rctoris/) (rctoris@wpi.edu)

Contributors
------------

 * [Jihoon Lee](http://notemywish.com) (jihoonlee.in@gmail.com)
